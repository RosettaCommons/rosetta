# -*- tab-width:2;indent-tabs-mode:t;show-trailing-whitespace:t;rm-trailing-spaces:t -*-
# vi: set ts=2 noet:
#
# (c) Copyright Rosetta Commons Member Institutions.
# (c) This file is part of the Rosetta software suite and is made available under license.
# (c) The Rosetta software is developed by the contributing members of the Rosetta Commons.
# (c) For more information, see http://www.rosettacommons.org. Questions about this can be
# (c) addressed to University of Washington UW TechTransfer, email: license@u.washington.edu.

check_setup()
feature_analyses <- c(feature_analyses, new("FeaturesAnalysis",
id = "buns_geom_sasa_x",
author = "Kevin Houlihan",
brief_description = "",
feature_reporter_dependencies = c("HBondFeatures"),
run=function(self, sample_sources, output_dir, output_formats){

sele <-"
SELECT
	acc.struct_id AS struct_id,
	acc.site_id AS site_id,
	hbenv.sasa_r040,
	hbenv.sasa_r060,
	hbenv.sasa_r080,
	hbenv.sasa_r100,
	hbenv.sasa_r120,
	hbenv.sasa_r140,
	hbenv.sasa_r160,
	hbenv.sasa_r180,
	hbenv.sasa_r200,
	hbenv.vsasa_r140
FROM
	hbond_site_environment AS hbenv,
	hbond_sites AS acc,
	hbond_sites_pdb AS acc_pdb
WHERE
	hbenv.sasa_r140 < 1 AND
	hbenv.site_id = acc.site_id AND acc.struct_id = hbenv.struct_id AND
	acc_pdb.struct_id = hbenv.struct_id AND acc_pdb.site_id = acc.site_id AND
	acc.is_donor = 0 AND
	--acc_pdb.heavy_atom_temperature < 30 AND
	NOT EXISTS (SELECT *
			FROM
				hbonds AS hb,
				hbond_geom_coords AS geom,
				hbond_sites AS don
			WHERE
				hb.struct_id = hbenv.struct_id AND
				geom.struct_id = hbenv.struct_id AND
				don.struct_id = hbenv.struct_id AND
				geom.hbond_id = hb.hbond_id AND
				hb.acc_id = acc.site_id AND
				hb.don_id = don.site_id AND
				abs(acc.resNum - acc.resNum) > 2 AND
				(hb.energy < 0 OR
					(geom.AHdist < 3.0 AND geom.cosAHD > -0.5 AND geom.cosBAH > -0.5)
				)
			);"
#abs(acc.resNum - acc.resNum) > 5 AND

f <- query_sample_sources(sample_sources, sele)

f <- na.omit(f, method="r")

#sasas = c("sasa_r040","sasa_r060","sasa_r080","sasa_r100","sasa_r120","sasa_r140",
#					"sasa_r160","sasa_r180","sasa_r200","vsasa_r140")
#for(sasa in sasas) {


#dens <- estimate_density_1d(
# data=f,
# ids = c("sample_source"),
# variable = sasa,
# adjust=.5)

f <- melt.data.frame(f, id=c("sample_source", "struct_id", "site_id"), variable_name="sasa_measure")

dodge <- position_dodge(width=0.9)

plot_id = "buns_sasas_jitter_acc"
#p <- ggplot(data=dens) + theme_bw() +
p <- ggplot(data=f) + theme_bw() +
	geom_jitter(aes(x=sample_source, y=value, colour=sample_source), position=dodge, alpha=0.5, size=0.5) +
	ggtitle(paste("Unsat Acceptor SASA Measures, geom Hbond cutoff, SASA by Atom")) +
	facet_wrap( ~ sasa_measure, nrow = 1, scales="free_y" ) +
	ylab(expression(paste('SASA (', ring(A)^2, ')'))) +
	xlab("SASA measure")
	#geom_indicator(aes(colour=sample_source, indicator=counts, group=sample_source))
	#scale_x_discrete(expression(paste('Burial (', ring(A), ')'))) +
	#geom_indicator(aes(colour=sample_source, indicator=burial, group=sample_source)) +
	#facet_grid(acc_chem_type_name ~ acc_chem_type_name) +
	#ggtitle("HBond Site sasa_r040, B-Fact < 30") +
	#scale_y_continuous("FeatureDensity", limits=c(0,30), breaks=c(0,10,20)) +
	#scale_y_continuous("FeatureDensity", limits=c(0, 10.5), breaks=c(0,1,2,3,4,5,6,7,8,9,10)) +

if(nrow(sample_sources) <= 3){
	p <- p + theme(legend.position="bottom", legend.direction="horizontal")
}

#ggsave(filename="test.png", plot=p)
save_plots(self, plot_id, sample_sources, output_dir, output_formats)

#} for loop

})) # end FeaturesAnalysis
