#!/usr/bin/env bash

~/Rosetta/main/source/cmake/build_release/rosetta_scripts \
	-database ~/Rosetta/main/database @flags
