# -*- tab-width:2;indent-tabs-mode:t;show-trailing-whitespace:t;rm-trailing-spaces:t -*-
# vi: set ts=2 noet:
#
# (c) Copyright Rosetta Commons Member Institutions.
# (c) This file is part of the Rosetta software suite and is made available under license.
# (c) The Rosetta software is developed by the contributing members of the Rosetta Commons.
# (c) For more information, see http://www.rosettacommons.org. Questions about this can be
# (c) addressed to University of Washington UW TechTransfer, email: license@u.washington.edu.

check_setup()
feature_analyses <- c(feature_analyses, new("FeaturesAnalysis",
id = "buns_burial_given_unsat",
author = "Kevin Houlihan",
brief_description = "",
feature_reporter_dependencies = c("HBondFeatures"),
run=function(self, sample_sources, output_dir, output_formats){

source("scripts/analysis/plots/hbonds/hbond_geo_dim_scales.R")

sele <-"
SELECT
	hbenv.sasa_r040,
	hbenv.sasa_r060,
	hbenv.sasa_r080,
	hbenv.sasa_r100,
	hbenv.sasa_r120,
	hbenv.sasa_r140,
	hbenv.sasa_r160,
	hbenv.sasa_r180,
	hbenv.sasa_r200,
	hbenv.vsasa_r140,
	cgroup.sasa_r040 AS group_sasa_r040,
	cgroup.sasa_r060 AS group_sasa_r060,
	cgroup.sasa_r080 AS group_sasa_r080,
	cgroup.sasa_r100 AS group_sasa_r100,
	cgroup.sasa_r120 AS group_sasa_r120,
	cgroup.sasa_r140 AS group_sasa_r140,
	cgroup.sasa_r160 AS group_sasa_r160,
	cgroup.sasa_r180 AS group_sasa_r180,
	cgroup.sasa_r200 AS group_sasa_r200,
	cgroup.vsasa_r140 AS vgroup_sasa_r140,
	don.HBChemType AS don_chem_type,
	(SELECT count(*)
			FROM
				hbonds AS hb,
				hbond_geom_coords AS geom,
				hbond_sites AS acc 
			WHERE
				hb.struct_id = hbenv.struct_id AND
				geom.struct_id = hbenv.struct_id AND
				acc.struct_id = hbenv.struct_id AND
				geom.hbond_id = hb.hbond_id AND
				hb.acc_id = acc.site_id AND
				hb.don_id = don.site_id AND
				abs(acc.resNum - don.resNum) > 2 AND
				(hb.energy < 0 OR
					(geom.AHdist < 3.0 AND geom.cosAHD > -0.5 AND geom.cosBAH > -0.5)
				)
	) AS num_geo_hbonds,
	(SELECT count(*)
			FROM
				hbonds AS hb,
				hbond_geom_coords AS geom,
				hbond_sites AS acc
			WHERE
				hb.struct_id = hbenv.struct_id AND
				geom.struct_id = hbenv.struct_id AND
				acc.struct_id = hbenv.struct_id AND
				geom.hbond_id = hb.hbond_id AND
				hb.acc_id = acc.site_id AND
				hb.don_id = don.site_id AND
				abs(acc.resNum - don.resNum) > 2 AND
				hb.energy < 0
	) AS num_nrg_hbonds
FROM
	hbond_site_environment AS hbenv,
	hbond_sites AS don,
	hbond_sites_pdb AS don_pdb,
	chem_group_sasa AS cgroup
WHERE
	don.struct_id = hbenv.struct_id AND
	don_pdb.struct_id = hbenv.struct_id AND
	don.struct_id = cgroup.struct_id AND
	hbenv.site_id = don.site_id AND
	don_pdb.site_id = don.site_id AND
	don.heavy_id = cgroup.heavy_id AND
	don.is_donor = 1;"

f <- query_sample_sources(sample_sources, sele)

f$don_chem_type_name <- don_chem_type_name_linear(f$don_chem_type)

f <- na.omit(f, method="r")

sasas = c("sasa_r040","sasa_r060","sasa_r080","sasa_r100","sasa_r120","sasa_r140",
					"sasa_r160","sasa_r180","sasa_r200","vsasa_r140")
for(sasa in sasas) {

g <- f[ f[,"num_geo_hbonds"] == 0 , c("sample_source", "don_chem_type_name", sasa) ]

dens <- estimate_density_1d_reflect_boundary(
 data=g,
 ids = c("sample_source", "don_chem_type_name"),
 reflect_left=TRUE,
 left_boundary=0,
 variable = sasa,
 adjust=.5)

plot_id = paste("buns_geom_hbonds_don_burial_given_unsat_", sasa, sep="")
p <- ggplot(data=dens) + theme_bw() +
	geom_line(aes(x=x, y=y, colour=sample_source)) +
	geom_indicator(aes(colour=sample_source, indicator=counts, group=sample_source)) +
	ggtitle(paste("SASA for Unsat Don, hbonds by geom, ", sasa, sep="")) +
	scale_x_continuous(expression(paste('Surface Area (', ring(A), '^2)')), limits=c(0, 5) ) +
	ylab("Density") +
	facet_wrap( ~ don_chem_type_name, scales = "free_y" )

if(nrow(sample_sources) <= 3){
	p <- p + theme(legend.position="bottom", legend.direction="horizontal")
}

save_plots(self, plot_id, sample_sources, output_dir, output_formats)

}

group_sasas = c("group_sasa_r040","group_sasa_r060","group_sasa_r080",
				"group_sasa_r100","group_sasa_r120","group_sasa_r140",
				"group_sasa_r160","group_sasa_r180","group_sasa_r200",
				"vgroup_sasa_r140")
for(group_sasa in group_sasas) {

g <- f[ f[,"num_geo_hbonds"] == 0 , c("sample_source", "don_chem_type_name", group_sasa) ]

dens <- estimate_density_1d(
 data=g,
 ids = c("sample_source", "don_chem_type_name"),
 reflect_left=TRUE,
 left_boundary=0,
 variable = group_sasa,
 adjust=.5)

plot_id = paste("buns_geom_hbonds_don_burial_given_unsat_", group_sasa, sep="")
p <- ggplot(data=dens) + theme_bw() +
	geom_line(aes(x=x, y=y, colour=sample_source)) +
	geom_indicator(aes(colour=sample_source, indicator=counts, group=sample_source)) +
	ggtitle(paste("SASA for Unsat Don, hbonds by geom, ", group_sasa, sep="")) +
	facet_wrap( ~ don_chem_type_name, scales = "free_y" ) +
	scale_x_continuous(expression(paste('Surface Area (', ring(A), '^2)')), limits=c(0, 10) ) +
	ylab("FeatureDensity")

if(nrow(sample_sources) <= 3){
	p <- p + theme(legend.position="bottom", legend.direction="horizontal")
}

save_plots(self, plot_id, sample_sources, output_dir, output_formats)

}

# Now HBonds by energy

for(sasa in sasas) {

g <- f[ f[,"num_nrg_hbonds"] == 0 , c("sample_source", "don_chem_type_name", sasa) ]

dens <- estimate_density_1d_reflect_boundary(
 data=g,
 ids = c("sample_source", "don_chem_type_name"),
 reflect_left=TRUE,
 left_boundary=0,
 variable = sasa,
 adjust=.5)

plot_id = paste("buns_nrg_hbonds_don_burial_given_unsat_", sasa, sep="")
p <- ggplot(data=dens) + theme_bw() +
	geom_line(aes(x=x, y=y, colour=sample_source)) +
	geom_indicator(aes(colour=sample_source, indicator=counts, group=sample_source)) +
	ggtitle(paste("SASA for Unsat Don, hbonds by nrg, ", sasa, sep="")) +
	scale_x_continuous(expression(paste('Surface Area (', ring(A), '^2)')), limits=c(0, 5) ) +
	ylab("Density") +
	facet_wrap( ~ don_chem_type_name, scales = "free_y" )

if(nrow(sample_sources) <= 3){
	p <- p + theme(legend.position="bottom", legend.direction="horizontal")
}

save_plots(self, plot_id, sample_sources, output_dir, output_formats)

}

for(group_sasa in group_sasas) {

g <- f[ f[,"num_nrg_hbonds"] == 0 , c("sample_source", "don_chem_type_name", group_sasa) ]

dens <- estimate_density_1d(
 data=g,
 ids = c("sample_source", "don_chem_type_name"),
 reflect_left=TRUE,
 left_boundary=0,
 variable = group_sasa,
 adjust=.5)

plot_id = paste("buns_nrg_hbonds_don_burial_given_unsat_", group_sasa, sep="")
p <- ggplot(data=dens) + theme_bw() +
	geom_line(aes(x=x, y=y, colour=sample_source)) +
	geom_indicator(aes(colour=sample_source, indicator=counts, group=sample_source)) +
	ggtitle(paste("SASA for Unsat Don, hbonds by nrg, ", group_sasa, sep="")) +
	facet_wrap( ~ don_chem_type_name, scales = "free_y" ) +
	scale_x_continuous(expression(paste('Surface Area (', ring(A), '^2)')), limits=c(0, 10) ) +
	ylab("FeatureDensity")

if(nrow(sample_sources) <= 3){
	p <- p + theme(legend.position="bottom", legend.direction="horizontal")
}

save_plots(self, plot_id, sample_sources, output_dir, output_formats)

}



})) # end FeaturesAnalysis
